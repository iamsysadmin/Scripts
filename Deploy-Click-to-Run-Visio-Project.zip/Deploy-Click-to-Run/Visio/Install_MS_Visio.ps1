﻿# Create Variables

$Logfile = "$env:windir\logs\Install_Visio.log"

$checkOfficeArchitectureInstalled = (Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration).Platform

$VisioDefaultArchitecture = "X86" #If no Microsoft 365 Apps are detected the script wil install this Visio Architecture

# Create Logfile Function

function WriteLog
{
Param ([string]$LogString)
$Stamp = (Get-Date).toString("dd/MM/yyy HH:mm:ss")
$LogMessage = "$Stamp $LogString"
Add-content $LogFile -value $LogMessage
}
If($checkOfficeArchitectureInstalled -eq $Null)

{

WriteLog "Microsoft 365 Apps not detected"
WriteLog "Use default architecture install $VisioDefaultArchitecture"
$Architecture = $VisioDefaultArchitecture

}

else

{

WriteLog "Microsoft 365 Apps $checkOfficeArchitectureInstalled detected" 
WriteLog "Use same architecture install for Visio as installed 365 Apps that is: $checkOfficeArchitectureInstalled"
$Architecture = $checkOfficeArchitectureInstalled

}

# Compile XML name based on detected architecture Microsoft Apps and install Visio

WriteLog "Compiling installation XML file name"
$XML = "Visio-"+$Architecture+".xml"
WriteLog "Used XML $XML for installation"

        Try
            {
                WriteLog "Starting Microsoft Visio $Architecture installation"
                $Process = Start-Process -FilePath $PSScriptRoot\setup.exe -ArgumentList "/configure $XML" -Wait -WindowStyle Hidden -ErrorAction Stop
                WriteLog "Finished installation of Microsoft Visio $Architecture"
            }

        Catch 
            {
              WriteLog "Microsoft Visio $Architecture installation failed"
              WriteLog $Error[0]
              
            }

