﻿$UninstallXML = "uninstall_Project.xml"

$Process = Start-Process -FilePath $PSScriptRoot\setup.exe -ArgumentList "/configure $UninstallXML" -Wait -WindowStyle Hidden

