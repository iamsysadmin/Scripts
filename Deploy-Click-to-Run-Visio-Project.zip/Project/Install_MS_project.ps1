﻿# Create Variables

$Logfile = "$env:windir\logs\Install_Project.log"

$checkOfficeArchitectureInstalled = (Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration).Platform

$ProjectDefaultArchitecture = "X86" #If no Microsoft 365 Apps are detected the script wil install this Project Architecture

# Create Logfile Function

function WriteLog
{
Param ([string]$LogString)
$Stamp = (Get-Date).toString("dd/MM/yyy HH:mm:ss")
$LogMessage = "$Stamp $LogString"
Add-content $LogFile -value $LogMessage
}
If($checkOfficeArchitectureInstalled -eq $Null)

{

WriteLog "Microsoft 365 apps not detected"
WriteLog "Use default architecture install $ProjectDefaultArchitecture"
$Architecture = $ProjectDefaultArchitecture

}

else

{

WriteLog "Microsoft 365 apps $checkOfficeArchitectureInstalled detected" 
WriteLog "Use same architecture install for Project as installed 365 Apps that is: $checkOfficeArchitectureInstalled"
$Architecture = $checkOfficeArchitectureInstalled

}

# Compile XML name based on detected architecture Microsoft Apps and install Project

WriteLog "Compiling installation XML file name"
$XML = "Project-"+$Architecture+".xml"
WriteLog "Used XML $XML for installation"

        Try
            {
                WriteLog "Starting Microsoft Project $Architecture installation"
                $Process = Start-Process -FilePath $PSScriptRoot\setup.exe -ArgumentList "/configure $XML" -Wait -WindowStyle Hidden -ErrorAction Stop
                WriteLog "Finished installation of Microsoft Project $Architecture"
            }

        Catch 
            {
              WriteLog "Microsoft Project $Architecture installation failed"
              WriteLog $Error[0]
              
            }

