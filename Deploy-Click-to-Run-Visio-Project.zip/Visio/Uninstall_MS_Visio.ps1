﻿$UninstallXML = "uninstall_Visio.xml"

$Process = Start-Process -FilePath $PSScriptRoot\setup.exe -ArgumentList "/configure $UninstallXML" -Wait -WindowStyle Hidden

