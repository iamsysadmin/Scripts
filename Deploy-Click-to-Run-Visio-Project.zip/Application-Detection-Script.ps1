﻿# Detection script for applications.
# Author = Remy Kuster
# Date = 30-08-2023
# Geef hieronder aan welke methode je wilt gebruiken voor de detectie

$DetectionMsiGUIDandVersion = "false" # Geef true of false in om de detectie obv installed msi guid en versienummer te doen.
$DetectionMsiGUID = "" # Geef de MSI GUID in als $DetectionMsiGUIDandVersion hierboven true is zonder {}.
$DetectionMsiVersion = "" # Geef de applicatie versie in die bij de MSI installatie hoort als $DetectionMsiGUIDandVersion hierboven true is.

$DetectionExeandVersion = "false" # Enter True or false to do the detection based on application exe and/or version number.
$DetectionExePath = "" # Enter the path to the exe including the exe name if $DetectionExeandVersion is true (example: C:\Program Files\Mozilla Firefox\Firefox.exe).
$DetectionExeRequiredVersion = "" # Enter the version of the executable if $DetectionExeandVersion is true and you also want to do detection on the version of the executable, if you only want to do detection on the executable name leave it blank.

$DetectionRegistryAppNameandEqVersion = "false" # Enter true or false to do the detection based on registry Application name AND the exact version number.
$DetectionRegistryAppName = "" # Enter the application name (DisplayName) associated with the Application found in one of these registry locations: hklm:\software\wow6432Node\microsoft\windows\Currentversion\uninstall or hklm:\software\microsoft\windows\Currentversion\uninstall if $DetectionRegistryAppNameandEqVersion above is true.
$DetectionRegistryVersion = "" # Enter the application version (DisplayVersion) found in one of these registry locations: hklm:\software\wow6432Node\microsoft\windows\Currentversion\uninstall or here hklm:\software\microsoft\windows\Currentversion\uninstall that belongs to the Application installation if $DetectionRegistryAppNameandEqVersion above is true.

$DetectionRegistryAppNameandEqANDGrThenVersion = "true" # Enter true or false to do the detection based on register Application name AND equal to and greater than the current version number, for example in the case of an application that updates automatically after installation to a newer version.
$DetectionRegistryAppName = "Microsoft Visio - en-us" # Enter the application name (DisplayName) associated with the Application found in one of these registry locations: hklm:\software\wow6432Node\microsoft\windows\Currentversion\uninstall or here hklm:\software\microsoft\windows\Currentversion\uninstall if $DetectionRegistryAppNameandEqANDGrThenVersion above is true.
$DetectionRegistryVersion = "16.0.16529.20226" # Enter the application version (DisplayVersion) found in one of these registry locations: hklm:\software\wow6432Node\microsoft\windows\Currentversion\uninstall or here hklm:\software\microsoft\windows\Currentversion\uninstall that belongs to the Application installation if $DetectionRegistryAppNameandEqANDGrThenVersion above is true.


if ($DetectionMsiGUIDandVersion -eq "True")

{
$InstalledApps = Get-WmiObject -Class Win32_Product | Where-Object -FilterScript {$_.IdentifyingNumber -EQ '{$DetectionMsiGUID}'}

if (($InstalledApps.IdentifyingNumber -eq '{$DetectionMsiGUID}') -and ($InstalledApps.Version -eq '$DetectionMsiVersion'))

{
Write-Host "Application is installed"
Exit 0
}

Else

{
Exit 0
}
}

if (($DetectionExeandVersion -eq "True") -and  ($DetectionExeRequiredVersion -notlike $null))

{
$DetectedExeVersion = (Get-Command $DetectionExePath).FileVersionInfo.FileVersion

if ($DetectedExeVersion -eq $DetectionExeRequiredVersion){

Write-Host "Application and version is installed"
Exit 0
}

Else

{
Exit 0
}
}

if (($DetectionExeandVersion -eq "True") -and (!$DetectionExeRequiredVersion -eq "true"))
{
$ExePathPresent = Test-Path $DetectionExePath

if ($ExePathPresent -eq "$true")

{
Write-Host "Application is installed"
Exit 0
}
Else
{
Exit 0
}
}

if ($DetectionRegistryAppNameandEqVersion -eq "True") 
{
$RegUninstallKeys = "hklm:\software\wow6432Node\microsoft\windows\Currentversion\uninstall", "hklm:\software\microsoft\windows\Currentversion\uninstall"
[array]$name = ($RegUninstallKeys | foreach-object {If (test-path $_) {GCI $_ | GP | select-object displayName,displayVersion}}) | where-object {$_.DisplayName -eq "$DetectionRegistryAppName" -and $_.DisplayVersion -eq $DetectionRegistryVersion}

if ($name -ne $Null) 
{
Write-Host "Application is installed"
Exit 0
} 
Else 
{

Exit 0
}
}

if ($DetectionRegistryAppNameandEqANDGrThenVersion -eq "True") 
{
$RegUninstallKeys = "hklm:\software\wow6432Node\microsoft\windows\Currentversion\uninstall", "hklm:\software\microsoft\windows\Currentversion\uninstall"
[array]$name = ($RegUninstallKeys | foreach-object {If (test-path $_) {GCI $_ | GP | select-object displayName,displayVersion}}) | where-object {$_.DisplayName -eq "$DetectionRegistryAppName" -and $_.DisplayVersion -ge $DetectionRegistryVersion}

if ($name -ne $Null) 
{
Write-Host "Application is installed"
Exit 0
} 
Else 
{

Exit 0
}
}

