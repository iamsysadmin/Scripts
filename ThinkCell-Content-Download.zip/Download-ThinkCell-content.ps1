﻿
# Script for downloading new content if new version ThinkCell msi is available and placing it in the PMP Repo folder.
# Remy Kuster
# 17-10-2024

$Logfile = "$PSScriptRoot\ThinkCell-repo-pmp.log"
$ProgressPreference = 'SilentlyContinue'

function WriteLog
{
Param ([string]$LogString)
$Stamp = (Get-Date).toString("dd/MM/yyyy HH:mm:ss")
$LogMessage = "$Stamp $LogString"
Add-content $LogFile -value $LogMessage
}

# PMP Repository destination (required)
$RepoDestination = ""

# Enter proxy if needed (proxy url:port)
$Proxy = ""

# Source file location URL recieved from Think-cell support (required)
$sourceUrl = ""

# Destination to save the latest new MSI file
$LocalSourceNew = "$PSScriptRoot\New"

$LocalSourceCurrentVersion = "$PSScriptRoot\Current"

# Get the download url and new FileName of Think-Cell latest version with or without Proxy depending on Proxy variable
If ($Proxy -eq "")
    {
    $response = Invoke-WebRequest -Uri $sourceUrl -MaximumRedirection 0 -UseBasicParsing
    }
    Else
    {
    $response = Invoke-WebRequest -Uri $sourceUrl -MaximumRedirection 0 -UseBasicParsing -Proxy $Proxy
    }


$location = $response.Headers.Location

if (([System.Uri]($location)).query -match "url=([^&]+)") { $DownloadUrl = [System.URI]::UnescapeDataString($matches[1]); $DownloadUrl -match "setup_think-cell_[0-9]+.msi"; $filename = $matches[0]}

$MsiNameThinkCellNew = $filename

# Get current Think-Cell msi name

$MsiNameThinkCellCurrent = (Get-ChildItem -Path "$LocalSourceCurrentVersion" | where {($_.Name -like "*.msi")}).name

# Check if new version is available, if so download new content an copy it to PMP repo

If (($MsiNameThinkCellCurrent -notmatch $MsiNameThinkCellNew) -or ($MsiNameThinkCellCurrent -eq $Null))

    {

    WriteLog "New version $MsiNameThinkCellNew available"

    # If proxy variable is Null run WebRequest without proxy parameter otherwise run with proxy parameter

    If ($Proxy -eq "")
    {
    WriteLog "Downloading $MsiNameThinkCellNew to $PSScriptRoot\New\$MsiNameThinkCellNew without Proxy" 

    Invoke-WebRequest -Uri $DownloadUrl -OutFile “$PSScriptRoot\New\$MsiNameThinkCellNew” -UseBasicParsing
    }
    Else
    {
    WriteLog "Downloading $MsiNameThinkCellNew to $PSScriptRoot\New\$MsiNameThinkCellNew with Proxy" 

    Invoke-WebRequest -Uri $DownloadUrl -OutFile “$PSScriptRoot\New\$MsiNameThinkCellNew” -UseBasicParsing -Proxy $Proxy
    }

    #Remove the MSI in current folder

    WriteLog "Removing $LocalSourceCurrentVersion\$MsiNameThinkCellCurrentMsiNameThinkCellNew"

    Remove-item -Path $LocalSourceCurrentVersion\$MsiNameThinkCellCurrent -Force

    #copy msi to location(s)

    WriteLog "Copy $MsiNameThinkCellNew to $LocalSourceCurrentVersion"

    Copy-Item -Path $LocalSourceNew\*.msi -Destination $LocalSourceCurrentVersion

    WriteLog "Move $MsiNameThinkCellNew from $LocalSourceNew to $RepoDestination"

    Move-Item -Path $LocalSourceNew\*.msi -Destination $RepoDestination

    }

    else

    {

    WriteLog "No new version found no download needed, exiting script"

    }

    exit


